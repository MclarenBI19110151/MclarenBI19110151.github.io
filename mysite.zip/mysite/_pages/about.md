---
layout: about
title: about
logo: "images/author.jpg"
permalink: "/about/"
--- 
About the Artist - Mclaren W. Yusof

Mclaren was born in the districts of Sabah at his hometown, Ranau. As a kid, Mclaren was loved to watch animated cartoons on the television. His favorite part of the day was watching Disney's animated character drawing and Art Attack back when Astro was still the go-to TV company.