---
layout: blog
title: blog
permalink: "/blog/"
sidebar: "recent_posts"
--- 
